#Question 1 countrymap table 
use zomato;
select *from zomata;
select distinct(country) from zomata;
select country,city, count(restaurantid) as count from zomato group by 1,2 order by 1;
create table countrycode(country_code int,country varchar(40));
insert into countrycode values(1,"India"),(14,"Australia"),(30,"Brazil"),(37,"Canada"),(37,"Canada"),
                               (94,"Indonasia"),(148,"New Zealand"),(162,"Phillipines"),(166,"Qatar"),
                               (184,"Singapur"),(189,"South Africa"),(191,"Srilanka"),(208,"Turkey"),
                               (214,"UAE"),(215,"United Kingdom"),(216,"United states");
 select * from countrycode;  
 with cte as(select * from zomata z
 join countrycode c
 on z.countrycode=c.country_code) 
 select  country,count(restaurantid) no_of_restaurants,
 round(avg(rating),2) as Average_ratings ,
 round(avg(Average_Cost_for_two)/2,2) as Average_cost,
 currency
 
 from cte group by 1,5;
 
#question 2 calender table
describe zomato;
select Datekey_opening from zomata;
alter table zomata modify datekey_opening date;
describe zomata;
 select datekey_opening as date_key, 
        month(datekey_opening) as month_no,
		day(datekey_opening) as Date,
        year(datekey_opening) as year,
        monthname(datekey_opening) as Name_of_month,
        dayname(datekey_opening) as Day,
        concat("Qtr-",quarter(datekey_opening)) as Quarter ,
        concat(year(datekey_opening),"-",date_format(datekey_opening,"%b")) as yyyy_mm,
        concat("FM-",if(month(datekey_opening)+3>12,month(datekey_opening)-9,month(datekey_opening)+3)) as Financial_mon,
        case when month(datekey_opening)+3 between 4 and 6 then "FQ-2"
             when month(datekey_opening)+3 between 7 and 9 then "FQ-3"
             when month(datekey_opening)+3 between 1 and 3 then "FQ-1"
             else "FQ-4" end Financial_qtr
        from zomata;
        
        
#Question 3. Find the Numbers of Resturants based on City and Country.
with cte as(select * from zomata z 
join countrycode c 
on z.countrycode=c.country_code)
select country,city,count(restaurantid) No_Restaurants 
from cte
group by 1,2
order by 1;

#Question 4. Numbers of Resturants opening based on Year , Quarter , Month
#yearwise
select year(datekey_opening),count(RestaurantID) from zomata group by 1;

#quarterwise
select quarter(datekey_opening) quarter,
        count(RestaurantID) No_Restaurants from zomata
group by 1 order by 1;

#monthwise
select month,No_Restaurants from
(select month(datekey_opening) mon, monthname(datekey_opening) Month,
count(RestaurantID) No_Restaurants from zomata group by 1,2) ab 
order by mon;

#table
select year,no_restaurants,month,quarter from 
 (select year(datekey_opening) year,
		count(RestaurantID) No_restaurants,
        monthname(datekey_opening) month,
        quarter(datekey_opening) quarter,
        month(datekey_opening) mon from zomata
        group by 1,3,4,5 order by 1,5)ab;
        

#Question 5 - Based on average rating
select  distinct rating,count(RestaurantID) No_restaurants from zomata group by 1;

#Question 6 -Bucket list
select 
case when Average_Cost_for_two<500 then "Low"
     when Average_Cost_for_two<1000 then "lower-mid"
     when average_cost_for_two<2000 then "Mid"
     when Average_Cost_for_two<3000 then "Upper-mid"
     else "High"
     End Bucket_list,
     round(avg(average_cost_for_two),1) Average_cost ,
     count(RestaurantID) No_restaurants from zomata
     group by 1 order by 2;
    
#Question 7.Percentage of Resturants based on "Has_Table_booking"

SELECT 
    Has_Table_booking,
    COUNT(*) AS count_restaurants,
    ROUND( (COUNT(*) * 100.0) / (SELECT COUNT(*) FROM zomata), 2) AS percentage
FROM 
    zomata
GROUP BY 
    Has_Table_booking;
    
#Question 8.Percentage of Resturants based on "Has_Online_delivery"

SELECT 
    Has_Online_delivery,
    COUNT(*) AS restaurant_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM zomata), 2) AS percentage
FROM 
    zomata
GROUP BY 
    Has_Online_delivery;
    


